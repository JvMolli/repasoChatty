export { default } from './containers/newGroup';
