export { default as friendRoutes } from './routes';
