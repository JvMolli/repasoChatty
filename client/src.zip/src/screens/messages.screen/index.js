export { default } from './containers/messages';
